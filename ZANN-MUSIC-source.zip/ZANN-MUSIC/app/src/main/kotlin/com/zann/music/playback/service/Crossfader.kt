package com.zann.music.playback.service

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MediaSource
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@UnstableApi
class Crossfader(
    private val context: Context,
    private val main: ExoPlayer,
    private val sourceFactory: MediaSource.Factory,
    /** Builds the tail's audio pipeline; it is handed a reader for the id of the track the tail plays. */
    private val renderers: ((() -> String?) -> androidx.media3.exoplayer.RenderersFactory)? = null,
) {
    @Volatile private var tailMediaId: String? = null
    private enum class Phase { IDLE, PREPARING, FADING }

    private var tail: ExoPlayer? = null
    private var phase = Phase.IDLE
    private var handoffAtMs = 0L
    private var windowMs = 0L
    private var preparedIndex = C.INDEX_UNSET
    private var fadeStartElapsed = 0L
    private var fadeInPending = false
    private var fadeInStartElapsed = 0L
    var expectedIndex = C.INDEX_UNSET
        private set

    val isActive get() = phase != Phase.IDLE || fadeInPending || fadeInStartElapsed > 0L

    fun tick(enabled: Boolean, seconds: Float, outer: Float): Float {
        val now = SystemClock.elapsedRealtime()
        if (fadeInPending && main.isPlaying) {
            fadeInPending = false
            fadeInStartElapsed = now
        }
        when (phase) {
            Phase.IDLE -> if (enabled) maybePrepare(seconds)
            Phase.PREPARING -> {
                val pos = main.currentPosition
                val t = tail
                when {
                    !enabled || t == null || main.currentMediaItemIndex != preparedIndex || pos < handoffAtMs - PREPARE_LEAD_MS - 1500 -> cancel()
                    pos >= handoffAtMs && t.playbackState == Player.STATE_READY -> handoff(now)
                    pos >= handoffAtMs + GIVE_UP_MS -> cancel()
                }
            }
            Phase.FADING -> {
                val start = when {
                    fadeInStartElapsed > 0L -> fadeInStartElapsed
                    now - fadeStartElapsed >= MAX_FADE_IN_WAIT_MS -> fadeStartElapsed + MAX_FADE_IN_WAIT_MS
                    else -> 0L
                }
                val f = if (start == 0L) 0f else ((now - start).toFloat() / windowMs).coerceIn(0f, 1f)
                tail?.volume = cos(f * PI / 2).toFloat() * outer
                if (f >= 1f || tail?.playbackState == Player.STATE_ENDED) stopTail()
            }
        }
        if (fadeInStartElapsed > 0L) {
            val f = ((now - fadeInStartElapsed).toFloat() / windowMs.coerceAtLeast(1L)).coerceIn(0f, 1f)
            if (f >= 1f) fadeInStartElapsed = 0L
            return sin(f * PI / 2).toFloat()
        }
        return if (fadeInPending) 0f else 1f
    }

    private fun maybePrepare(seconds: Float) {
        if (main.repeatMode == Player.REPEAT_MODE_ONE || !main.hasNextMediaItem()) return
        if (main.playbackState != Player.STATE_READY) return
        val duration = main.duration
        if (duration == C.TIME_UNSET || duration <= 0L) return
        val window = (seconds * 1000).toLong().coerceIn(1000L, 12_000L)
        if (duration < window * 3) return
        val handoff = duration - window
        val pos = main.currentPosition
        if (pos < handoff - PREPARE_LEAD_MS || pos > handoff - 500) return

        val item: MediaItem = main.currentMediaItem ?: return
        val t = tail ?: buildTail().also { tail = it }
        tailMediaId = item.mediaId
        t.setMediaSource(sourceFactory.createMediaSource(item), handoff)
        t.volume = 0f
        t.playWhenReady = false
        t.prepare()
        phase = Phase.PREPARING
        handoffAtMs = handoff
        windowMs = window
        preparedIndex = main.currentMediaItemIndex
    }

    private fun handoff(now: Long) {
        val t = tail ?: return cancel()
        val drift = main.currentPosition - handoffAtMs
        if (drift > MAX_DRIFT_MS) t.seekTo(handoffAtMs + drift)
        t.volume = main.volume
        t.playbackParameters = main.playbackParameters
        t.play()
        expectedIndex = main.nextMediaItemIndex
        main.volume = 0f
        fadeInPending = true
        fadeInStartElapsed = 0L
        phase = Phase.FADING
        fadeStartElapsed = now
        main.seekToNextMediaItem()
    }

    fun cancel() {
        if (phase == Phase.IDLE && !fadeInPending && fadeInStartElapsed == 0L) return
        stopTail()
        fadeInPending = false
        fadeInStartElapsed = 0L
    }

    fun onTransition(index: Int): Boolean {
        val ours = index == expectedIndex && phase == Phase.FADING
        expectedIndex = C.INDEX_UNSET
        if (!ours) cancel()
        return ours
    }

    private fun stopTail() {
        tail?.let {
            it.stop()
            it.clearMediaItems()
        }
        phase = Phase.IDLE
        preparedIndex = C.INDEX_UNSET
        expectedIndex = C.INDEX_UNSET
    }

    private fun buildTail(): ExoPlayer {
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val builder = renderers?.let { ExoPlayer.Builder(context, it { tailMediaId }) } ?: ExoPlayer.Builder(context)
        return builder
            .setMediaSourceFactory(sourceFactory)
            .setAudioAttributes(attrs, false)
            .build()
            .also { it.setAudioSessionId(main.audioSessionId) }
    }

    fun onAudioSessionChanged(id: Int) {
        tail?.setAudioSessionId(id)
    }

    fun release() {
        tail?.release()
        tail = null
        phase = Phase.IDLE
    }

    private companion object {
        const val PREPARE_LEAD_MS = 4_000L
        const val GIVE_UP_MS = 1_500L
        const val MAX_DRIFT_MS = 150L
        const val MAX_FADE_IN_WAIT_MS = 4_000L
    }
}
