/*
 * Vendored from Kyant0/backdrop v2.0.0 (io.github.kyant0:backdrop)
 * https://github.com/Kyant0/backdrop — Copyright 2025 Kyant0, Apache License 2.0
 *
 * Vendored so the library ships as source with this app (binary AARs compiled
 * against older Compose broke at runtime) and to add a backdrop resolution
 * scale for cheaper effect rendering. KMP expect/actual declarations were
 * merged into this single Android source set. Package renamed accordingly.
 */
package com.zann.music.ui.glass.backdrop.effects

import androidx.compose.ui.graphics.RenderEffect
import com.zann.music.ui.glass.backdrop.BackdropEffectScope
import com.zann.music.ui.glass.backdrop.RuntimeShader
import com.zann.music.ui.glass.backdrop.internal.RuntimeShaderEffect
import com.zann.music.ui.glass.backdrop.internal.chain
import com.zann.music.ui.glass.backdrop.isRenderEffectSupported
import com.zann.music.ui.glass.backdrop.isRuntimeShaderSupported
import kotlin.contracts.ExperimentalContracts
import org.intellij.lang.annotations.Language

fun BackdropEffectScope.effect(effect: RenderEffect) {
    if (!isRenderEffectSupported()) return

    renderEffect = renderEffect.chain(effect)
}

@OptIn(ExperimentalContracts::class)
fun BackdropEffectScope.runtimeShaderEffect(
    key: String,
    @Language("AGSL") shaderString: String,
    uniformShaderName: String,
    block: RuntimeShader.() -> Unit
) {
    if (!isRuntimeShaderSupported()) return

    val effect =
        RuntimeShaderEffect(
            runtimeShader = obtainRuntimeShader(key, shaderString).apply(block),
            uniformShaderName = uniformShaderName
        )
    renderEffect = renderEffect.chain(effect)
}
